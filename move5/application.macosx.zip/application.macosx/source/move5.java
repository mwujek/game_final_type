import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shiffman.box2d.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.joints.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.collision.shapes.Shape; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.contacts.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class move5 extends PApplet {

//You have to add processing library first!!
//sketch > import library > add library > "box2d for processing"







int i = 9;
//collision detection










Box2DProcessing box2d; 

boolean flashingL;
float flashOpacityL;    
float flashHeightL;

ArrayList<Boundary> boundaries;


//score, lives, and text stuff
PFont apercu;
float flashHeight;
int targetScore;
int displayScore;
boolean flashDifference;
boolean state=false;
boolean flashing=false;
int addedScore;
int diff;
float flashOpacity=255;

float growingBox;
boolean invincibility=true;

int amtLives = 5;
String lives="lives: ";
String scoreString="score: ";

String levelEnd = "level complete! ";
String yourScore = "Your score is: ";
boolean addScoreTime = true;
float counter = 0;
float counterLife = 0;
float counterSpeed= 6;

boolean runonce = true;

//keys and coins

boolean keyFound = false;
float xPosKey;
float yPosKey;
float distFromKey;
boolean levelComplete = false;
float filling;
float speed = 5;
boolean goingDown;
boolean down;
float opacity = 0;
PImage keyIcon;
PImage bg;
PImage ship;

float bgXPos =2;
float bgYPos =2;





float x, y, thrust, inverseDrag, velocityX, velocityY, angle, torque;
boolean[] keyIsPressed = new boolean[256];
Circle[] circles = new Circle[10];

//box2d variables 
int scaleFactor = 10;
float radius = 10f;
float radiusDifference= 20;
float restitutionValue = 0.0f;
float blurValue=1;
float margin= 0.0f;
float red = 0.0f;
float green = 0.0f;
float blue = 0.0f;
float creationRate = 0.0f;

int bonus;

float backgroundColor = 255;

//Easing Trail
int num = 20;
float mx[] = new float[num];
float my[] = new float[num];


//attractor objects
Attractor easyAttractor;

ArrayList<AttractedCircle> attractedCircles;
float targetX;
float targetY;
//timing 
int savedTime;
int totalTime = 2500;

public void setup() {
  //timing
  savedTime = millis();
  keyIcon = loadImage("star.png");
  bg = loadImage("bg.jpg");
  ship = loadImage("ship.png");
  apercu = loadFont("Apercu-Bold-48.vlw");
  textFont(apercu);


  size(600, 600);
  xPosKey = random(0, width/3);
  //yPosKey = random(height/2, height-40);
  yPosKey = 100;

  x = 50;
  y = 200;
  thrust = 0.20f;
  inverseDrag = 0.97f;
  velocityX = 0;
  velocityY = 0;
  angle = 0.0f;
  torque = radians(5.0f);

  // Initialize and create the Box2D world
  box2d = new Box2DProcessing(this);  
  box2d.createWorld();
  box2d.setGravity(0, 0);

  for (int i = 0; i < circles.length; i++) {
    circles[i] = new Circle((width/2+100), random(height-50), 50, radiusDifference, 4, margin, PApplet.parseInt(random(50, 100)), PApplet.parseInt(random(-50, -200)));
  }


  boundaries = new ArrayList<Boundary>();

  boundaries.add(new Boundary(0, height-5, width*2, 10));
  boundaries.add(new Boundary(0, 5, width*2, 10));
  boundaries.add(new Boundary(width-5, height/2, 10, height));
  boundaries.add(new Boundary(5, height/2, 10, height));


  //setup attractors
  easyAttractor = new Attractor(12, mouseX, mouseY);
  attractedCircles = new ArrayList<AttractedCircle>();
}


public void draw() {

  // Calculate how much time has passed
  int passedTime = millis() - savedTime;
  targetX = x;
  targetY = y;
  //if(

  image(bg, -50+(targetX/25), -50+(targetY/25));
  bgXPos = constrain(bgXPos, -50, 500);
  bgYPos = constrain(bgXPos, -50, 500);

  //score constraints
  displayScore = constrain(displayScore, 0, 1000000); 
  targetScore = constrain(targetScore, 0, 1000000); 
  if (targetScore > displayScore) {
    displayScore++;
    flashDifference=true;
    //println(addedScore);
  }

  if (displayScore > targetScore) {
    displayScore--;
    flashDifference=true;
  }

  if (displayScore == targetScore) {
    flashDifference = false;
  }

  if (flashDifference) {
    //println(diff);
  }



  //println("target: " + targetScore);





  x = constrain(x, 10, width-10);
  y = constrain(y, 10, height-10);

  //flux opacity
  if (down) {
    opacity -=speed;
  } 
  else {
    opacity +=speed;
  }
  if (opacity > 255) {
    down = true;
  } 
  if (opacity<50) {
    down = false;
  }

  // update before stepping
  easyAttractor.update(x, y);

  box2d.step();   
  //looks for distance from key

  //opacity tint below
  //fill(backgroundColor, opacity);
  //rect(xPosKey, yPosKey, 50, 50);

  //ellipse(xPosKey, yPosKey, 30, 30);
  distFromKey = dist(x, y, xPosKey, yPosKey);
  if (distFromKey<32) {
    keyFound = true;
    addscore(50);
  }

  if (keyFound) {
    xPosKey = -100;
    yPosKey = -100;
    if (frameCount % 50 ==0) {
      resetKey();
      keyFound = false;
    }
  }

  velocityX *= inverseDrag;
  velocityY *= inverseDrag;
  x += velocityX;
  y += velocityY;

  if (x > width + 30)
    x = -30;
  else if (x < -30)
    x = width + 30;
  if (y > height + 30)
    y = -30;
  else if (y < -30)
    y = height + 30;

  if (keyIsPressed[LEFT])
    angle -= torque;
  if (keyIsPressed[RIGHT])
    angle += torque;
  if (keyIsPressed[UP]) {
    velocityX += cos(angle) * thrust;
    velocityY += sin(angle) * thrust;
  }
  if (keyIsPressed[DOWN]) {
    velocityX -= cos(angle) * thrust;
    velocityY -= sin(angle) * thrust;
  }

  pushMatrix();
  fill(0xffff88ff);
  translate(x, y);
  rotate(angle);
  noStroke();

  //triangle(-10, -10, 15, 0, -10, 10);
  if (keyIsPressed[UP]) {
    fill(255, random(200), 0);
    ellipse(-16, 0, random(1, 6), random(1, 6));
    ellipse(-9, 10, random(1, 4), random(1, 4));
    ellipse(-9, -10, random(1, 4), random(1, 4));
  }
  tint(255);
  image(ship, -15, -17);
  if (invincibility) {
    noFill();
    if (state) {
      stroke(255);
      fill(255, 100);
    }
    else {
      noStroke();
    }
    if (frameCount%10==0) {
      state=!state;
    }
    ellipse(0, 0, 50, 50);

    if (passedTime > totalTime) {
      println( " 5 seconds have passed! " );
      invincibility =false;
    }
  }


  //origin
  //ellipse(0,0,2,2);
  popMatrix();  

  showScore();

  //circles!!

  for (int i = 0; i < circles.length; i++) {
    // Look, this is just like what we had before!
    circles[i].display();
    if (frameCount%500==0) {
      circles[i].energy();
    }
    if (circles[i].collided()&&invincibility ==false) {
      fill(0xff1BAA85);
      ellipse(x, y, 10, 10);
      noFill();
      restart();
    }
  }

  //display and update attractors
  if (frameCount % 350 == 0 || frameCount<4) {
    AttractedCircle ea = new AttractedCircle(width-20, 20, random(20, 30), 10, 0.5f, -1);
    attractedCircles.add(ea);
    //circles =  append(circles, circles);

  }

  for (int i = 0; i < attractedCircles.size()-1; i++) {
    // Look, this is just like what we had before!
    Vec2 force = easyAttractor.attract(attractedCircles.get(i));
    attractedCircles.get(i).applyForce(force);
    attractedCircles.get(i).displayEasyCircles();


    if (attractedCircles.get(i).collidedA() && invincibility ==false) {
      fill(0xff1BAA85);
      ellipse(x, y, 10, 10);
      noFill();
      restart();
    }
  }

  //Is there more than 1 life?
  if (amtLives < 1) {
    gameOver();
  }
  tint(255, opacity);  // Display at half opacity
  if (addScoreTime) {
    image(keyIcon, xPosKey, yPosKey);
  }

  if (flashing) {
    fill(255, flashOpacity);
    flashOpacity-=5;
    flashHeight-=0.5f;
    text("+10", 68, (height-20)+flashHeight);
    if (flashOpacity<0) {
      flashing=false;
    }
  }
  else {
    flashOpacity=255;
    flashHeight= 0;
  }

  if (flashingL) {
    fill(255, 100, 0, flashOpacityL);
    flashOpacityL-=5;
    flashHeightL-=0.5f;
    text("-1", 168, (height-20)+flashHeightL);
    if (flashOpacityL<0) {
      flashingL=false;
    }
  }
  else {
    flashOpacityL=255;
    flashHeightL= 0;
  }
  println(addedScore);
} //end draw loop 

public void levelCompleted() {
  addScoreTime = false;
  background(0);
  fill(0xffffcc00);
  textSize(28);
  if (runonce) {
    addscore(100);
    runonce = false;
  }
  text(levelEnd + yourScore +displayScore, 50, height/2);
}


public void gameOver() {
  addScoreTime = false;
  displayScore = displayScore;
  rectMode(CENTER);
  fill(0);
  x=-50;
  y=-50;

  if (growingBox<width+100) {
    growingBox+=10;
  }
  rect(width/2, height/2, growingBox, growingBox);

  fill(0xffffcc00);
  //textSize(28);
  text("Game Over!", 100, height/2);
  text("Your final score is: " + displayScore, 100, (height/2)+35);
}




public void keyPressed() {
  keyIsPressed[keyCode] = true;
  if (key =='r' && addScoreTime==false || key=='R' && addScoreTime==false) {
    setup();
    addScoreTime = true;
    amtLives = 5;
    targetScore=0;
  }
}



public void keyReleased() {
  keyIsPressed[keyCode] = false;
}


public void showScore() {
  fill(255);
  textSize(22);
  if (displayScore < targetScore) {
    fill(0xffffcc00);
  }
  if (displayScore > targetScore) {
    fill(0xffFF0000);
  }
  text(scoreString + displayScore, 10, height-10);
  fill(255);
  text(lives + amtLives, 120, height-10);

  if (addScoreTime) {
    if (frameCount % 60 == 0) {
      targetScore+=1;
    }
  }
}

public void restart() {
  invincibility=true;

  savedTime = millis(); // Save the current time to restart the timer!
  x=15;
  y=15;
  flashingL=true;
  velocityX = 0;
  velocityY = 0;
  if (addScoreTime) {
    amtLives-=1;
    addscore(-30);
  }
  //invincibility=true;
}

public int addscore (int addedScore) {
  targetScore += addedScore;

  flashDifference(addedScore);
  int diff = targetScore-displayScore;

  return addedScore;
}

public void flashDifference(int addedScore) {
  flashing=true;
}





public void resetKey() {
  xPosKey =random(50, width-50);
  yPosKey = random(50, height-50);
}



//void flashingScore(int addedScore){
//  fill(0);
//  text(addedScore, 150,150);
//}

//void mousePressed(){
//  amtLives = 5;
//}

// A circle!
class AttractedCircle {
  //  Instead of any of the usual variables, we will store a reference to a Box2D Body
  Body body;  
  Fixture fixture;
  PImage img;

  float w, h, r, filling, opacity;
  float scaled;
  boolean startGrowing;
  float inc = TWO_PI/25.0f; //used for smoothing 'easing' on radius growth/shrinking
  float a =0.0f;
  AttractedCircle(float x, float y, float radius, float radiusDifference, float restitutionValue, float margin) {
    opacity=255;

    r = 10;

    filling = random(60, 190);
    // Build Body
    BodyDef bd = new BodyDef();      
    bd.type = BodyType.DYNAMIC;
    bd.position.set(box2d.coordPixelsToWorld(x, y));
    body = box2d.createBody(bd);



    // Define a circle
    CircleShape cs = new CircleShape();

    cs.m_radius = box2d.scalarPixelsToWorld(r/2);

    // Define a fixture
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    // Parameters that affect physics
    fd.density = 1;
    fd.friction = 0.3f;
    fd.restitution = 0.0f;

    // Attach Fixture to Body               
    fixture = body.createFixture(fd);
  }

  public void displayEasyCircles() {
    // We need the Body\u2019s location and angle
    Vec2 pos = box2d.getBodyPixelCoord(body);    
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x, pos.y);    // Using the Vec2 position and float angle to
    //rotate(-a);     // translate and rotate the rectangle
    noStroke();
    fill(255,0,0); //red

    ellipseMode(CENTER);
    ellipse(0, 0, 10, 10);
    popMatrix();
  }





  // This function removes the particle from the box2d world
  public void killBody() {
    box2d.destroyBody(body);
  }
  public void applyForce(Vec2 v) {
    body.applyForce(v, body.getWorldCenter());
  }

  // Is the particle ready for deletion?
  public boolean done() {
    // Let's find the screen position of the particle
    Vec2 pos = box2d.getBodyPixelCoord(body);
    // Is it off the bottom of the screen?
    if (pos.y > height || opacity<20) {
      killBody();
      return true;
    }
    return false;
  }
  
  
  public boolean collidedA(){
    Vec2 pos = box2d.getBodyPixelCoord(body);
    float distanceFromPoint = dist(x,y,pos.x, pos.y);
    if(distanceFromPoint<r+15){
      return true;
    }
    return false;
  }
}

// The Nature of Code
// <http://www.shiffman.net/teaching/nature>
// Spring 2011
// Box2DProcessing example

// Showing how to use applyForce() with box2d

// Fixed Attractor (this is redundant with Mover)

class Attractor {
  
  // We need to keep track of a Body and a radius
  Body body;
  Fixture fixture;
  float r;

  Attractor(float r_, float x, float y) {
    r = r_;
    // Define a body
    BodyDef bd = new BodyDef();
    bd.type = BodyType.STATIC;
    // Set its position
    bd.position = box2d.coordPixelsToWorld(x,y);
    body = box2d.world.createBody(bd);

    // Make the body's shape a circle
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(r);
    fixture = body.createFixture(cs, 1);
    //body.createFixture(cs,1);

  }


  // Formula for gravitational attraction
  // We are computing this in "world" coordinates
  // No need to convert to pixels and back
  public Vec2 attract(AttractedCircle ea) {
    float G = 60; // Strength of force
    // clone() makes us a copy
    Vec2 pos = body.getWorldCenter();    
    Vec2 moverPos = ea.body.getWorldCenter();
    // Vector pointing from mover to attractor
    Vec2 force = pos.sub(moverPos);
    float distance = force.length();
    // Keep force within bounds
    distance = constrain(distance,1,5);
    force.normalize();
    // Note the attractor's mass is 0 because it's fixed so can't use that
    float strength = (G * 1 * ea.body.m_mass) / (distance * distance); // Calculate gravitional force magnitude
    force.mulLocal(strength);         // Get force vector --> magnitude * direction
    return force;
  }

  
  public void update(float x, float y){
    body.destroyFixture(fixture);
    // Define a body
    BodyDef bd = new BodyDef();
    bd.type = BodyType.STATIC;
    // Set its position
    bd.position = box2d.coordPixelsToWorld(x,y);
    body = box2d.world.createBody(bd);

    // Make the body's shape a circle
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(r);
     fixture = body.createFixture(cs, 1);
  }
}


// The Nature of Code
// <http://www.shiffman.net/teaching/nature>
// Spring 2012
// Box2DProcessing example

// A fixed boundary class

class Boundary {

  // A boundary is a simple rectangle with x,y,width,and height
  float x;
  float y;
  float w;
  float h;
  
  // But we also have to make a body for box2d to know about it
  Body b;

  Boundary(float x_,float y_, float w_, float h_) {
    x = x_;
    y = y_;
    w = w_;
    h = h_;

    // Define the polygon
    PolygonShape sd = new PolygonShape();
    // Figure out the box2d coordinates
    float box2dW = box2d.scalarPixelsToWorld(w/2);
    float box2dH = box2d.scalarPixelsToWorld(h/2);
    // We're just a box
    sd.setAsBox(box2dW, box2dH);


    // Create the body
    BodyDef bd = new BodyDef();
    bd.type = BodyType.STATIC;
    bd.position.set(box2d.coordPixelsToWorld(x,y));
    b = box2d.createBody(bd);
        bd.linearDamping = 0.0f;
bd.angularDamping = 0.0f;

    // Attached the shape to the body using a Fixture
    b.createFixture(sd,1);
    
  }

  // Draw the boundary, if it were at an angle we'd have to do something fancier
  public void display() {
    fill(0);
    stroke(0);
    rectMode(CENTER);
    rect(x,y,w,h);
  }

}


// A circle!
class Circle {
  //  Instead of any of the usual variables, we will store a reference to a Box2D Body
  Body body;  
  Fixture fixture;
  float energyValue;
  PImage img;

  float radius;
  float w, h, r, filling, opacity;
  float scaled;
  boolean startGrowing;
  float inc = TWO_PI/25.0f; //used for smoothing 'easing' on radius growth/shrinking
  float a =0.0f;
  Circle(float x, float y, float radius, float radiusDifference, float restitutionValue, float margin, int xPush, int yPush) {
    opacity=255;
    w = 16;
    h = 16;
    r = random(radius, radius+radiusDifference);



    filling = random(60, 190);
    // Build Body
    BodyDef bd = new BodyDef();      
    bd.type = BodyType.DYNAMIC;
    bd.position.set(box2d.coordPixelsToWorld(x, y));
    body = box2d.createBody(bd);



    // Define a circle
    CircleShape cs = new CircleShape();

    cs.m_radius = box2d.scalarPixelsToWorld(r/(2-margin));

    // Define a fixture
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    // Parameters that affect physics
    fd.density = 5.0f;
    fd.friction = 0.0f;
    fd.restitution = 0.45f;


    //body.setLinearVelocity(new Vec2(0,3));
    body.setLinearVelocity(new Vec2(xPush, yPush));

    // Attach Fixture to Body               
    fixture = body.createFixture(fd);
  }
  //  void update(){
  //    //Destroy the old fixture; we'll replace it in a sec
  //        body.destroyFixture(fixture);
  //        body.createFixture(p); //density after comma
  //
  //  }
  public void display() {
    // We need the Body\u2019s location and angle
    Vec2 pos = box2d.getBodyPixelCoord(body);    
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x, pos.y);    // Using the Vec2 position and float angle to
    noStroke();
    //image(img, 0, 0);
    fill(0xfffc0fc0, 100); //blue

    ellipseMode(CENTER);
    ellipse(0, 0, r, r);

    popMatrix();
  }

  public void energy() {
    energyValue = random(1);
    float energy = map(energyValue, 0, 1, -5, 5);
    body.setLinearVelocity(new Vec2(energy, energy));
  }




  // This function removes the particle from the box2d world
  public void killBody() {
    box2d.destroyBody(body);
  }
  public void applyForce(Vec2 v) {
    body.applyForce(v, body.getWorldCenter());
  }

  // Is the particle ready for deletion?
  public boolean done() {
    // Let's find the screen position of the particle
    Vec2 pos = box2d.getBodyPixelCoord(body);
    // Is it off the bottom of the screen?
    if (pos.y > height || opacity<20) {
      killBody();
      return true;
    }
    return false;
  }

  //    void change() {
  //      println("bleh");
  //  }
  //returns value for collision
  public boolean collided() {
    Vec2 pos = box2d.getBodyPixelCoord(body);
    float distanceFromPoint = dist(x, y, pos.x, pos.y);
    if (distanceFromPoint<(r/2)+16) {
      return true;
    }
    return false;
  }
 
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "move5" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
